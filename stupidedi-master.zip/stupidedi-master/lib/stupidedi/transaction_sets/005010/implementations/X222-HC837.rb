# frozen_string_literal: true
module Stupidedi
  module TransactionSets
    module FiftyTen
      module Implementations
        module X222
          warn "DEPRECATION WARNING: #{self}::HC837 is deprecated, use X222A1::HC837 instead"

          # @deprecated Use X222A1::HC837 instead
          HC837 = X222A1::HC837
        end
      end
    end
  end
end
