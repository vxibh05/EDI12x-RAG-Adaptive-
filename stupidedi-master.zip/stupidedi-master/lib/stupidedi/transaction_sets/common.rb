# frozen_string_literal: true
module Stupidedi
  module TransactionSets
    module Common
      autoload :Implementations, "stupidedi/transaction_sets/common/implementations"
    end
  end
end
