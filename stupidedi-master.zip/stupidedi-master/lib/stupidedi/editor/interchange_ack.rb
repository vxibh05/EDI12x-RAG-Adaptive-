# frozen_string_literal: true
module Stupidedi
  using Refinements

  module Editor
    # Generates a TA1 acknowledgment
    class InterchangeAck
    end
  end
end
