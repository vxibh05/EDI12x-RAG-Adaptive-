# frozen_string_literal: true
module Stupidedi
  using Refinements

  module Editor
    # Generates a 277CA acknowledgement
    class ClaimAck
    end
  end
end
