module Stupidedi
  warn "DEPRECATION WARNING: Stupidedi::Builder is depecated, use Stupidedi::Parser instead"

  # @deprecated Use Stupidedi::Parser instead
  Builder = Parser
end
