# frozen_string_literal: true
module Stupidedi
  module Versions
    module ThirtyTen
      module ElementTypes
        TM      = Common::ElementTypes::TM
        TimeVal = Common::ElementTypes::TimeVal
      end
    end
  end
end
