# frozen_string_literal: true
module Stupidedi
  module Versions
    module ThirtyTen
      module ElementTypes
        DT      = Common::ElementTypes::DT
        DateVal = Common::ElementTypes::DateVal
      end
    end
  end
end
