# frozen_string_literal: true
module Stupidedi
  module Versions
    module TwoThousandOne
      module ElementTypes
        AN        = Common::ElementTypes::AN
        StringVal = Common::ElementTypes::StringVal
      end
    end
  end
end
