# frozen_string_literal: true
module Stupidedi
  module Versions
    module TwoThousandOne
      module ElementTypes
        DT      = Common::ElementTypes::DT
        DateVal = Common::ElementTypes::DateVal
      end
    end
  end
end
