# frozen_string_literal: true
module Stupidedi
  module Versions
    module ThirtyForty
      module ElementTypes
        DT      = Common::ElementTypes::DT
        DateVal = Common::ElementTypes::DateVal
      end
    end
  end
end
