# frozen_string_literal: true
module Stupidedi
  module Versions
    module ThirtyForty
      module ElementTypes
        R        = Common::ElementTypes::R
        FloatVal = Common::ElementTypes::FloatVal
      end
    end
  end
end
