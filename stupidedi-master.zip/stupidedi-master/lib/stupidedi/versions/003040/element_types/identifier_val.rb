# frozen_string_literal: true
module Stupidedi
  module Versions
    module ThirtyForty
      module ElementTypes
        ID            = Common::ElementTypes::ID
        IdentifierVal = Common::ElementTypes::IdentifierVal
      end
    end
  end
end
