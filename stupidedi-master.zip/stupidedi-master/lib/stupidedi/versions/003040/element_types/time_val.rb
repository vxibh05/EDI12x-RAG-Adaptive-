# frozen_string_literal: true
module Stupidedi
  module Versions
    module ThirtyForty
      module ElementTypes
        TM      = Common::ElementTypes::TM
        TimeVal = Common::ElementTypes::TimeVal
      end
    end
  end
end
