# frozen_string_literal: true
module Stupidedi
  module Exceptions
    class ZipperError < StupidediError
    end
  end
end
