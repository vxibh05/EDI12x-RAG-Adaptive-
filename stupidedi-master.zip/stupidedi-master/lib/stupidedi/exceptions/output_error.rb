# frozen_string_literal: true
module Stupidedi
  module Exceptions
    class OutputError < StupidediError
    end
  end
end
