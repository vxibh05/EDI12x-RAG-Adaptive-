# frozen_string_literal: true
module Stupidedi
  module Exceptions
    class StupidediError < StandardError
    end
  end
end
