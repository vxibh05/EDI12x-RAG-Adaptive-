# frozen_string_literal: true
module Stupidedi
  module Exceptions
    class TokenizeError < StupidediError
    end
  end
end
