# frozen_string_literal: true
module Stupidedi
  module Exceptions
    class InvalidSchemaError < StupidediError
    end
  end
end
