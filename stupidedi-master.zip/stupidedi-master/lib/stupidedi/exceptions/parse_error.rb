# frozen_string_literal: true
module Stupidedi
  module Exceptions
    class ParseError < StupidediError
    end
  end
end
