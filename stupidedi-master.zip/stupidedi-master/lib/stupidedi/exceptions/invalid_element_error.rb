# frozen_string_literal: true
module Stupidedi
  module Exceptions
    class InvalidElementError < StupidediError
    end
  end
end
