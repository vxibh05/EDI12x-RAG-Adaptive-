# frozen_string_literal: true
module Stupidedi
  VERSION = "1.4.5"
end
