Serializing X12
==============

Once you have built a parse tree, either by generating one programatically (see
{file:Generating.md Generating}) or parsing serialized input (see
{file:Parsing.md}), you can serialize it back to a string using one of the
classes in [`Stupidedi::Writer`][1].
